#!/usr/bin/env python3
"""Regenerate the skin's procedural media assets.

These are plain white shapes with the colour carried entirely in alpha;
skin XML tints them at runtime via colordiffuse, so one asset serves every
accent colour. Supersampled 4x and downsampled for anti-aliased edges.
"""
import pathlib
from PIL import Image, ImageDraw

MEDIA = pathlib.Path(__file__).resolve().parent.parent / "media"
SCALE = 4


def rounded_rect(size, radius, out_path):
    w, h = size
    img = Image.new("RGBA", (w * SCALE, h * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(
        (0, 0, w * SCALE - 1, h * SCALE - 1),
        radius=radius * SCALE,
        fill=(255, 255, 255, 255),
    )
    img = img.resize((w, h), Image.LANCZOS)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    print(f"wrote {out_path} ({w}x{h})")


def now_line(size, line_width, out_path):
    """Dim fill on the left, a crisp opaque line along the right edge --
    used with <progresstexture border="0,0,line_width,0">, so the right
    border stays pixel-exact while the dim fill stretches to span the
    grid's already-elapsed time."""
    w, h = size
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rectangle((0, 0, w - line_width - 1, h - 1), fill=(255, 255, 255, 40))
    draw.rectangle((w - line_width, 0, w - 1, h - 1), fill=(255, 255, 255, 255))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path)
    print(f"wrote {out_path} ({w}x{h})")


if __name__ == "__main__":
    rounded_rect((16, 16), radius=4, out_path=MEDIA / "lists" / "cell.png")
    rounded_rect((24, 24), radius=6, out_path=MEDIA / "lists" / "row_focus.png")
    now_line((8, 64), line_width=3, out_path=MEDIA / "windows" / "pvr" / "now_line.png")
